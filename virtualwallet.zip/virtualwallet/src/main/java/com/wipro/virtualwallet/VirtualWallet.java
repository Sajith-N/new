package com.wipro.virtualwallet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wipro.virtualwallet.dao.UserCardsRepository;
import com.wipro.virtualwallet.dao.UserTableRepository;
import com.wipro.virtualwallet.model.UserCards;
import com.wipro.virtualwallet.model.UserTable;



@SpringBootApplication
@ComponentScan({"com.wipro.virtualwallet","com.wipro.virtualwallet.model.UserCards"})
@EnableJpaRepositories(basePackages="com.wipro.virtualwallet.dao")
public class VirtualWallet implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(VirtualWallet.class, args);
	}
@Autowired
UserCardsRepository userCardsRepository;

@Autowired
UserTableRepository userTableRepository;

@Override
	public void run(ApplicationArguments args) throws Exception {
	UserTable userTable = new UserTable();
	userTable.setUsername("walletuser0");
	userTable.setPassword("wallet@2020");
	userTable.setNoOfCards(0);
	userTable.setWalletBalance(100000.0);
	userTableRepository.saveAndFlush(userTable);
	UserTable userTable1 = new UserTable();
	userTable1.setUsername("walletuser2");
	userTable1.setPassword("wallet@2020");
	userTable1.setNoOfCards(2);
	userTable1.setWalletBalance(100000.0);
	userTableRepository.saveAndFlush(userTable1);
	UserTable usertable2=new UserTable();
	usertable2.setUsername("walletuser3");
	usertable2.setPassword("wallet@2020");
	usertable2.setNoOfCards(3);
	usertable2.setWalletBalance(100000.0);
	userTableRepository.saveAndFlush(usertable2);
UserCards userCards= new UserCards();
userCards.setUsername("walletuser2");
userCards.setCardname("Kindle subscription");
userCards.setCardNumber("5459606654580156");
userCards.setExpiryDate("02/2050");
userCards.setCardBalance("5000");
userCardsRepository.saveAndFlush(userCards);
UserCards userCards2= new UserCards();
userCards2.setUsername("walletuser2");
userCards2.setCardname("Drop shopping");
userCards2.setCardNumber("4569587957853258");
userCards2.setExpiryDate("08/2050");
userCards2.setCardBalance("1200");
userCardsRepository.saveAndFlush(userCards2);
  UserCards usercards3= new UserCards();
usercards3.setUsername("walletuser3");	
usercards3.setCardname("Kindle subscription");
usercards3.setCardNumber("5459578554580156");
usercards3.setExpiryDate("02/2050");
usercards3.setCardBalance("10000");
userCardsRepository.saveAndFlush(usercards3);
UserCards usercards4 = new UserCards();
usercards4.setUsername("walletuser3");
usercards4.setCardname("Drop shopping");
usercards4.setCardNumber("5785587957853258");
usercards4.setExpiryDate("08/2050");
usercards4.setCardBalance("10000");
userCardsRepository.saveAndFlush(usercards4);
UserCards usercards5 = new UserCards();
usercards5.setUsername("walletuser3");
usercards5.setCardname("Jackie chan");
usercards5.setCardNumber("4257654865204528");
usercards5.setExpiryDate("11/2050");
usercards5.setCardBalance("10000");
userCardsRepository.saveAndFlush(usercards5);
}
}
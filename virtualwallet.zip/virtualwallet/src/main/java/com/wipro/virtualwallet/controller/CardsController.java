package com.wipro.virtualwallet.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wipro.virtualwallet.dao.UserCardsRepository;
import com.wipro.virtualwallet.dao.UserTableRepository;
import com.wipro.virtualwallet.model.RandomCardNumberGenerator;
import com.wipro.virtualwallet.model.UserCards;
import com.wipro.virtualwallet.model.UserTable;

@Controller
@SessionAttributes({"username","CardsRemaining"})
public class CardsController {

	@Autowired
	UserTableRepository userTableRepository;
	
	
	@Autowired
	UserCardsRepository userCardsRepository;
	
	@GetMapping(value = "/create_card")
	public String addCardsPage(UserCards usercards,ModelMap model) {
		model.addAttribute("addcard", new UserCards());
		model.addAttribute("balance", 10000);
		return "CreateCard";
	}


	   @ModelAttribute("walletBalances")
	   public List<String> getWalletBalances() {
	      List<String> numbersList = new ArrayList<String>();
	      numbersList.add("My Wallet");
	      return numbersList;
	   }
	
	@GetMapping(value = "/view_cards")
	public String viewCardsPage(ModelMap model) {
String username = model.getAttribute("username").toString();
List<UserCards> usercards= userCardsRepository.findByUsername(username);
model.addAttribute("lists",usercards);
		model.addAttribute("addcard", new UserCards());
		if(usercards.size()>2) {
			model.addAttribute("information", "You have reached the limit to create new card");
		}
		return "ViewCards";
	}

    @GetMapping(value="/create_card/view_cards")	
	public String viewCards() {
	return "redirect:/view_cards"; 
}
    
    @GetMapping(value="/topup_card")	
	public String topupCardsPage(ModelMap model,@ModelAttribute("cardnames") List<String> cardnames,@ModelAttribute("balances") List<UserCards> cards) {
    	model.addAttribute("topupcard", new UserCards());
    	String username=model.getAttribute("username").toString();
    	List<UserCards> users=userCardsRepository.findByUsername(username);
    	cards=users;
    	for(UserCards u:users) {
    		cardnames.add(u.getCardname());
    	}
    	
	return "Topup"; 
}
    @PostMapping(value="/topup_card")	
	public String topupCreatePage() {
	return "Topup"; 
}
    
	@GetMapping(value = "/dashboard")
	public String ViewDashboardPage(ModelMap model) {
String username = model.getAttribute("username").toString();
Optional<UserTable> usertable=userTableRepository.findById(username);
model.put("CardsRemaining", (3-usertable.get().getNoOfCards()));
model.addAttribute("WalletBalance",usertable.get().getWalletBalance());
return "Dashboard";
	}

	
	@PostMapping(value = "/create_card")
	public String registerCardsPage(@Valid UserCards usercards,ModelMap model,BindingResult result,HttpServletRequest request,RedirectAttributes  attributes) {
		if(result.hasErrors()) {
			return "CreateCard";
		}
		int i=Integer.parseInt(usercards.getCardBalance());

		if(i>10000) {
			attributes.addFlashAttribute("cardFailureText", "Virtual card creation Failed, Total amount exceeds the maximum limit (INR 10,000) allowed")	;	
	
		return "redirect:create_card/error";
		}
		System.out.println("In random Number class"+RandomCardNumberGenerator.randomNumber());
		usercards.setCardNumber(RandomCardNumberGenerator.randomNumber());
		String cards=model.getAttribute("CardsRemaining").toString();
	int card=Integer.parseInt(cards);
	if(card==1) {
		usercards.setExpiryDate("02/2050");
	}
	else if(card==2) {
		usercards.setExpiryDate("08/2050");
	}
	else {
		usercards.setExpiryDate("11/2050");
	}
	 i=10000-Integer.parseInt(usercards.getCardBalance());
	usercards.setWalletBalance(String.valueOf(i));
	System.out.println("Card number in Create card mapping "+usercards.getCardNumber());
	attributes.addFlashAttribute("usercardnumber",usercards.getCardNumber());
	usercards.setUsername(model.getAttribute("username").toString());
//	request.setAttribute("usercardnumber", usercards.getCardNumber());
	//System.out.println("request card number "+request.getAttribute("usercardnumber"));
	userCardsRepository.saveAndFlush(usercards);
		return "redirect:/create_card/success";
	}
	
	@GetMapping(value = "/create_card/success")
	public String cardCreated(@ModelAttribute("usercardnumber") String cardnumber,ModelMap model) {
		model.addAttribute("success","Virtual card Created");
	System.out.println("User card number "+cardnumber);
UserCards usercard=	userCardsRepository.findByCardNumber(cardnumber);
		model.addAttribute("cardname", usercard.getCardname());
		model.addAttribute("cardnumber", usercard.getCardNumber());
		model.addAttribute("expiry", usercard.getExpiryDate());
		model.addAttribute("cardbalance", usercard.getCardBalance());
		return "CreateCardSuccess";
	}

	@GetMapping(value = "/create_card/error")
	
	public String cardCreatedError(ModelMap model,@ModelAttribute("cardFailureText") String cardFailureText) {
		model.addAttribute("cardFailureText"
				+ "", cardFailureText);
		return "CreateCardError";
	}
}

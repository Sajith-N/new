package com.wipro.virtualwallet.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.wipro.virtualwallet.dao.UserCardsRepository;
import com.wipro.virtualwallet.dao.UserTableRepository;
import com.wipro.virtualwallet.model.UserTable;

@Controller
@SessionAttributes("username")
public class LoginController  {
	
	@Autowired
	UserTableRepository userTableRepository;
	
	@GetMapping(value="/login")
	public String showLoginPage(ModelMap model) {
		return "Login";
	}
	
	@PostMapping(value="/login")
	public String checkLoginDetails(ModelMap model,@RequestParam("username") String username,@RequestParam("password") String password){
			
	boolean userCheckFlag = userTableRepository.existsById(username);
			Optional<UserTable> usr=userTableRepository.findById(username);
			if(userCheckFlag) {
				if(usr.get().getUsername().equals(username) && usr.get().getPassword().equals(password)) {
					model.addAttribute("username", username);
					return "redirect:dashboard";
				}
			}
			model.addAttribute("error","Invalid Credentials");
			return "Login";

}}
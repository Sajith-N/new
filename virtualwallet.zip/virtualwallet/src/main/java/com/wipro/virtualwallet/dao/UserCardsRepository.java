package com.wipro.virtualwallet.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wipro.virtualwallet.model.UserCards;

@Repository
public interface UserCardsRepository extends JpaRepository<UserCards,String>{

public UserCards findByCardNumber(String cardNumber);

@Query("SELECT p FROM UserCards p WHERE p.username = ?1")
public List<UserCards> findByUsername(String name);
}

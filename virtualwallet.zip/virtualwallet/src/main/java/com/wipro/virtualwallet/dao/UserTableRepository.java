package com.wipro.virtualwallet.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.virtualwallet.model.UserTable;

@Repository
public interface UserTableRepository extends JpaRepository<UserTable, String>{
	
public UserTable findByUsername(String username);

}

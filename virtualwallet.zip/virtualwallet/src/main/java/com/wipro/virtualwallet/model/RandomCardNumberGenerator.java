package com.wipro.virtualwallet.model;

import java.util.Random;

import org.aspectj.weaver.StaticJoinPointFactory;

import net.bytebuddy.utility.RandomString;

public class RandomCardNumberGenerator {

public static String randomNumber() { 		
int i=(int) Math.floor(10000000 + Math.random() * 90000000);
String prefixFixedValue="64623434";
String cardnumber=prefixFixedValue.concat(String.valueOf(i));
return cardnumber;
}
}

package com.wipro.virtualwallet.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "USERCARDS")
public class UserCards {
	
@Id	
String cardNumber;

String username;

@Length(min = 1,max = 20)
String cardname;

String expiryDate;
String cardBalance;
String walletBalance;


public String getWalletBalance() {
	return walletBalance;
}

public void setWalletBalance(String walletBalance) {
	this.walletBalance = walletBalance;
}

/*
public UserCards(String cardNumber, String username, String cardname, String expiryDate, String cardBalance) {
	super();
	this.cardNumber = cardNumber;
	this.username = username;
	this.cardname = cardname;
	this.expiryDate = expiryDate;
	this.cardBalance = cardBalance;
}
*/
public UserCards() {
	
}

public String getCardNumber() {
	return cardNumber;
}
public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}



public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getCardname() {
	return cardname;
}
public void setCardname(String cardname) {
	this.cardname = cardname;
}
public String getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(String expiryDate) {
	this.expiryDate = expiryDate;
}
public String getCardBalance() {
	return cardBalance;
}
public void setCardBalance(String cardBalance) {
	this.cardBalance = cardBalance;
}
}

package com.wipro.virtualwallet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "USERTABLE")
public class UserTable {

	@Id
	String username;
	
	String password;
	@Column(name = "NoOfCards")
	int NoOfCards;
	double WalletBalance;
	/*
	public Usertable(String username, String password, int noOfCards, double walletBalance) {
		super();
		this.username = username;
		this.password = password;
		NoOfCards = noOfCards;
		WalletBalance = walletBalance;
	}
*/
	public UserTable() {
	
	}
	

	public double getWalletBalance() {
		return WalletBalance;
	}

	public void setWalletBalance(double walletBalance) {
		WalletBalance = walletBalance;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getNoOfCards() {
		return NoOfCards;
	}
	public void setNoOfCards(int noOfCards) {
		NoOfCards = noOfCards;
	}
}

INSERT INTO USERTABLE (username, password, NoOfCards,WalletBalance) VALUES ('walletuser0', 'wallet@2020', 0,10000.0);
INSERT INTO USERTABLE (username, password, NoOfCards,WalletBalance) VALUES ('walletuser2', 'wallet@2020', 2,10000.0);
INSERT INTO USERTABLE (username, password, NoOfCards,WalletBalance) VALUES('walletuser3', 'wallet@2020',3,10000.0);
INSERT INTO usercards (username, cardname, cardNumber,ExpiryDate,CardBalance) VALUES ('walletuser2', 'Kindle subscription','5459606654580156','02/2050','5000');
INSERT INTO usercards (username, cardname, cardNumber,ExpiryDate,CardBalance) VALUES ('walletuser2', 'Drop shopping', '4569587957853258','08/2050','1200');
INSERT INTO usercards (username, cardname, cardNumber,ExpiryDate,CardBalance) VALUES ('walletuser3', 'Kindle subscription','5459578554580156','02/2050','10000');
INSERT INTO usercards (username, cardname, cardNumber,ExpiryDate,CardBalance) VALUES ('walletuser3', 'Drop shopping','5785587957853258','08/2050','10000');
INSERT INTO usercards (username, cardname, cardNumber,ExpiryDate,CardBalance) VALUES ('walletuser3', 'Jackie chan','4257654865204528','11/2050','10000');
  
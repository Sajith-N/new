DROP TABLE IF EXISTS usertable;
 
CREATE TABLE usertable (  username VARCHAR(250) NOT NULL,
  password VARCHAR(250) NOT NULL,
  NoOfCards INT,
  WalletBalance DECIMAL(6.2));
  
    
  DROP TABLE IF EXISTS usercards;
  
  CREATE TABLE usercards(
  username VARCHAR(250) NOT NULL,
  cardname VARCHAR(250) NOT NULL,
  cardNumber VARCHAR(16) NOT NULL,
  ExpiryDate VARCHAR(16)NOT NULL,
  CardBalance VARCHAR(250) NOT NULL);
  
  


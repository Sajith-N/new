$(document).ready(function() {
        $('#Search').click(function(event) {
                var department = $('#department').val();
                var semester = $('#semester').val();
                $.get('College_Management_Service/CourseResult.jsp', {
                	Department : department,
                	Semester : semester
                }, function(responseText) {
                        $('#ajaxGetUserServletResponse').html($(document));
                });
        });
});